import { ChartsGuard } from './charts.guard';

export const guards = [ChartsGuard];

export * from './charts.guard';
