import { ChartsService } from './charts.service';
import { RegisterService } from './register.service';

export const services = [ChartsService,RegisterService];

export * from './charts.service';
export * from './register.service';
export const Config = {
	API_BASE_PATH : 'http://34.237.70.31/medirecx-dev-api/api/v1/',
	//API_BASE_PATH : 'http://localhost:1337/api/v1/',
    TIMEOUT_SECONDS: 3000000000000,
    API_OTHERS_KEY : "aHC$kykHa=aZHC#yZZkA$#HyHaCkH=k#akHkkZ$C$ZaAakHZ",
    SUBDOMAIN: "",
}