import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Config} from './../index';

@Component({
  selector: 'sb-list-register',
  templateUrl: './list-register.component.html',
  styleUrls: ['./list-register.component.scss']
})
export class ListRegisterComponent implements OnInit {
  clients: any;
  resData: any;
  constructor(
    private router : Router,
  ) { }
  
  ngOnInit() {
  
    this.getUsers();
  }
  getUsers() {
    this.clients = Config.DummyData;
    // this.clientService.getRegisterRecords().then((result) => {
    //     this.resData = result;
    //     this.clients = this.resData.data;
    //     this.dtTrigger.next();
    //     },error => {
    //     this.spinner.hide();
    //     this.loading = false;
    //     //this.changePasswordForm.reset();
    //     this.toastr.error(error);
    // });
  }

}
