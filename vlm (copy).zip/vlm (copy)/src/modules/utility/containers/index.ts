import { VersionComponent } from './version/version.component';

export const containers = [
    VersionComponent,
];

export * from './version/version.component';
