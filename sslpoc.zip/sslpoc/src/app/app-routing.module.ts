import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogInComponent } from './components/log-in/log-in.component';
import { RegisterComponent } from './components/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { QrcodeScanComponent } from './components/qrcodescan/qrcodescan.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { UsersComponent } from './components/users/users.component';
import { SchemasComponent } from './components/schemas/schemas.component';
import { CredentialdefComponent } from './components/credentialdef/credentialdef.component';
import { ConnectionsComponent } from './components/connections/connections.component';
import { ProfileComponent } from './components/profile/profile.component'

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LogInComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent, children:[
    {path:'dashboard',component:DashboardComponent},
    {path:'users',component:UsersComponent},
    {path:'schemas',component:SchemasComponent},
    {path:'credentialdef',component:CredentialdefComponent},
    {path:'connections',component:ConnectionsComponent},
    {path:'profile',component:ProfileComponent},
  ]},
  {path:'dashboard',component:DashboardComponent},
  {path:'users',component:UsersComponent},
  {path:'schemas',component:SchemasComponent},
  {path:'credentialdef',component:CredentialdefComponent},
  {path:'connections',component:ConnectionsComponent},
  {path:'profile',component:ProfileComponent},
  { path: 'qrcodescan', component:QrcodeScanComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
