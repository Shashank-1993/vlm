
import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-schemas',
  templateUrl: './schemas.component.html',
  styleUrls: ['./schemas.component.css']
})
export class SchemasComponent implements OnInit {
  
  

  // returns all form groups under contacts

  constructor() {}

  ngOnInit() {
    
   
  }

 

  // add a contact form group



}