import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QrcodescanComponent } from './qrcodescan.component';

describe('QrcodescanComponent', () => {
  let component: QrcodescanComponent;
  let fixture: ComponentFixture<QrcodescanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QrcodescanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QrcodescanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
