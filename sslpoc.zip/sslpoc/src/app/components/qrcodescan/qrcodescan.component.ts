import { Component } from '@angular/core';
import { NgxQrcodeElementTypes, NgxQrcodeErrorCorrectionLevels } from '@techiediaries/ngx-qrcode';

 
@Component({
  selector: 'app-qrcodescan',
  templateUrl: './qrcodescan.component.html',
  styleUrls: ['./qrcodescan.component.css']
})
export class QrcodeScanComponent {
  elementType = NgxQrcodeElementTypes.URL;
  correctionLevel = NgxQrcodeErrorCorrectionLevels.HIGH;
  value =JSON.stringify(
    {"@type": "did:sov:BzCbsNYhMrjHiqZDTUASHg;spec/connections/1.0/invitation",
    "@id": "24bf8b6a-08af-4516-8b2e-b06465420429",
    "label": "Hospital Agent",
    "recipientKeys": ["5A8tjT6JCBh3Nba6xa1WtCJa5ivJw84oqqSmm9iDKqFn"],
    "serviceEndpoint": "http://10.20.0.27:8070"});
}