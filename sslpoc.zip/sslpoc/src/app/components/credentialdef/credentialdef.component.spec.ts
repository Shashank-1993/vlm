import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CredentialdefComponent } from './credentialdef.component';

describe('CredentialdefComponent', () => {
  let component: CredentialdefComponent;
  let fixture: ComponentFixture<CredentialdefComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CredentialdefComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CredentialdefComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
