import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credentialdef',
  templateUrl: './credentialdef.component.html',
  styleUrls: ['./credentialdef.component.css']
})
export class CredentialdefComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
